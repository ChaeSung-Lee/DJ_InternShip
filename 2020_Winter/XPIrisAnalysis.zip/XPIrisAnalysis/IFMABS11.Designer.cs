﻿namespace XPIrisAnalysis
{
    partial class IFMABS11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbInfoVersion = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbInfoUpdate = new System.Windows.Forms.Label();
            this.lbInfoCompany = new System.Windows.Forms.Label();
            this.lbInfoQuestion = new System.Windows.Forms.Label();
            this.lbInfoGuide = new System.Windows.Forms.Label();
            this.lbInfoCertification = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Location = new System.Drawing.Point(39, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(724, 367);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 2;
            // 
            // lbInfoVersion
            // 
            this.lbInfoVersion.AutoSize = true;
            this.lbInfoVersion.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoVersion.Location = new System.Drawing.Point(86, 94);
            this.lbInfoVersion.Name = "lbInfoVersion";
            this.lbInfoVersion.Size = new System.Drawing.Size(202, 15);
            this.lbInfoVersion.TabIndex = 2;
            this.lbInfoVersion.Text = "XPEyeIn 100 20.sa2910.1322";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 15);
            this.label3.TabIndex = 2;
            // 
            // lbInfoUpdate
            // 
            this.lbInfoUpdate.AutoSize = true;
            this.lbInfoUpdate.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoUpdate.Location = new System.Drawing.Point(86, 135);
            this.lbInfoUpdate.Name = "lbInfoUpdate";
            this.lbInfoUpdate.Size = new System.Drawing.Size(112, 15);
            this.lbInfoUpdate.TabIndex = 2;
            this.lbInfoUpdate.Text = "Update Program";
            // 
            // lbInfoCompany
            // 
            this.lbInfoCompany.AutoSize = true;
            this.lbInfoCompany.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoCompany.Location = new System.Drawing.Point(86, 334);
            this.lbInfoCompany.Name = "lbInfoCompany";
            this.lbInfoCompany.Size = new System.Drawing.Size(123, 15);
            this.lbInfoCompany.TabIndex = 2;
            this.lbInfoCompany.Text = "Xion Process co.";
            // 
            // lbInfoQuestion
            // 
            this.lbInfoQuestion.AutoSize = true;
            this.lbInfoQuestion.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoQuestion.Location = new System.Drawing.Point(86, 220);
            this.lbInfoQuestion.Name = "lbInfoQuestion";
            this.lbInfoQuestion.Size = new System.Drawing.Size(132, 15);
            this.lbInfoQuestion.TabIndex = 3;
            this.lbInfoQuestion.Text = "Question of E-mail";
            // 
            // lbInfoGuide
            // 
            this.lbInfoGuide.AutoSize = true;
            this.lbInfoGuide.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoGuide.Location = new System.Drawing.Point(86, 178);
            this.lbInfoGuide.Name = "lbInfoGuide";
            this.lbInfoGuide.Size = new System.Drawing.Size(45, 15);
            this.lbInfoGuide.TabIndex = 3;
            this.lbInfoGuide.Text = "Guide";
            // 
            // lbInfoCertification
            // 
            this.lbInfoCertification.AutoSize = true;
            this.lbInfoCertification.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbInfoCertification.Location = new System.Drawing.Point(86, 262);
            this.lbInfoCertification.Name = "lbInfoCertification";
            this.lbInfoCertification.Size = new System.Drawing.Size(83, 15);
            this.lbInfoCertification.TabIndex = 3;
            this.lbInfoCertification.Text = "Certification";
            // 
            // IFMABS11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.lbInfoGuide);
            this.Controls.Add(this.lbInfoCertification);
            this.Controls.Add(this.lbInfoQuestion);
            this.Controls.Add(this.lbInfoCompany);
            this.Controls.Add(this.lbInfoUpdate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbInfoVersion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "IFMABS11";
            this.Text = "프로그램 정보";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbInfoVersion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbInfoUpdate;
        private System.Windows.Forms.Label lbInfoCompany;
        private System.Windows.Forms.Label lbInfoQuestion;
        private System.Windows.Forms.Label lbInfoGuide;
        private System.Windows.Forms.Label lbInfoCertification;
    }
}