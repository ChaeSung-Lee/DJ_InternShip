﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XPIrisAnalysis
{
    public partial class FLMABS11 : Form
    {
        public FLMABS11()
        {
            InitializeComponent();
        }

        private void btnPrintOut_Click(object sender, EventArgs e)
        {

        }
    }
}
