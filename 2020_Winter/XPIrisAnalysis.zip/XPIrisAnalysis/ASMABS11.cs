﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XPIrisAnalysis
{
    public partial class ASMABS11 : Form
    {
        public ASMABS11()
        {
            InitializeComponent();
        }

        private void btnTakePicture_Click(object sender, EventArgs e)
        {
            //ASMABS12 showForm = new ASMABS12();
            //MainForm parent = (MainForm)this.MdiParent;
            //parent.OpenForm(this, showForm);
        }
    }
}
