﻿namespace XPIrisAnalysis
{
    partial class RGMABS22
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbPatientName = new System.Windows.Forms.TextBox();
            this.tbPatientAge = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPatientSexual = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbPatientEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbPatientMobile = new System.Windows.Forms.TextBox();
            this.btnRegistPatient = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(60, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "이름";
            // 
            // tbPatientName
            // 
            this.tbPatientName.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbPatientName.Location = new System.Drawing.Point(347, 46);
            this.tbPatientName.Name = "tbPatientName";
            this.tbPatientName.Size = new System.Drawing.Size(175, 30);
            this.tbPatientName.TabIndex = 1;
            // 
            // tbPatientAge
            // 
            this.tbPatientAge.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbPatientAge.Location = new System.Drawing.Point(347, 114);
            this.tbPatientAge.Name = "tbPatientAge";
            this.tbPatientAge.Size = new System.Drawing.Size(175, 30);
            this.tbPatientAge.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(60, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "나이";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(60, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "성별";
            // 
            // tbPatientSexual
            // 
            this.tbPatientSexual.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbPatientSexual.Location = new System.Drawing.Point(347, 185);
            this.tbPatientSexual.Name = "tbPatientSexual";
            this.tbPatientSexual.Size = new System.Drawing.Size(175, 30);
            this.tbPatientSexual.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(60, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 23);
            this.label4.TabIndex = 2;
            this.label4.Text = "이메일";
            // 
            // tbPatientEmail
            // 
            this.tbPatientEmail.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbPatientEmail.Location = new System.Drawing.Point(347, 242);
            this.tbPatientEmail.Name = "tbPatientEmail";
            this.tbPatientEmail.Size = new System.Drawing.Size(175, 30);
            this.tbPatientEmail.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(60, 304);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 23);
            this.label5.TabIndex = 2;
            this.label5.Text = "모바일";
            // 
            // tbPatientMobile
            // 
            this.tbPatientMobile.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbPatientMobile.Location = new System.Drawing.Point(347, 305);
            this.tbPatientMobile.Name = "tbPatientMobile";
            this.tbPatientMobile.Size = new System.Drawing.Size(175, 30);
            this.tbPatientMobile.TabIndex = 3;
            // 
            // btnRegistPatient
            // 
            this.btnRegistPatient.Location = new System.Drawing.Point(156, 376);
            this.btnRegistPatient.Name = "btnRegistPatient";
            this.btnRegistPatient.Size = new System.Drawing.Size(294, 40);
            this.btnRegistPatient.TabIndex = 4;
            this.btnRegistPatient.Text = "등록";
            this.btnRegistPatient.UseVisualStyleBackColor = true;
            this.btnRegistPatient.Click += new System.EventHandler(this.btnRegistPatient_Click);
            // 
            // RGMABS22
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnRegistPatient);
            this.Controls.Add(this.tbPatientMobile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbPatientEmail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbPatientSexual);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbPatientAge);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbPatientName);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RGMABS22";
            this.Text = "RGMABS22";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbPatientName;
        private System.Windows.Forms.TextBox tbPatientAge;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPatientSexual;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbPatientEmail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbPatientMobile;
        private System.Windows.Forms.Button btnRegistPatient;
    }
}